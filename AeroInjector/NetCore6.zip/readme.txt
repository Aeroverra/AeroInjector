These files are created by making a basic console application and publishing it as self contained x-64 and then deleting the actual apps files.

The point of this is to be able to inject .net core into a native process and bootstrap without needing to rely on the user to have .net core installed